﻿param(
[Int32]$days=7,
[string]$ext='.bak',
[string[]]$folder
)

#add a wildcharacter to the extension
$ext = "*$ext"

#get date, find cutoff based on retention
$now = Get-Date
$lastWrite = $now.AddDays(-$days)
 
#debug
#$days
#$ext
#$folder
#$lastWrite

#get files based on lastwrite, extension, and specified folder
$files = Get-Childitem $folder -Filter $ext | Where {$_.LastWriteTime -le "$lastWrite"}

foreach ($file in $files) 
    {
    if ($file -ne $NULL)
        {
        write-host "Deleting File $file" -ForegroundColor "DarkRed"
        Remove-Item $file.FullName #| out-null
        }
    else
        {
        Write-Host "No more files to delete!" -foregroundcolor "Green"
        }
    }
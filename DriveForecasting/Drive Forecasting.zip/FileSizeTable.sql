USE [DBA]
GO

/****** Object:  Table [dbo].[FileSize]    Script Date: 8/5/2025 9:38:42 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[FileSize](
	[DatabaseName] [nvarchar](128) NULL,
	[FileName] [nvarchar](128) NULL,
	[Type] [nvarchar](128) NULL,
	[CurrentSizeMB] [decimal](10, 2) NULL,
	[FreeSpaceMB] [decimal](10, 2) NULL,
	[DriveLetter] [varchar](1) NULL,
	[CollectionTime] [date] NULL
) ON [PRIMARY]
GO



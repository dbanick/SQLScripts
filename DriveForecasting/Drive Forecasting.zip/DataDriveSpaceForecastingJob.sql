USE [msdb]
GO

/****** Object:  Job [Data Drive Space Forecasting]    Script Date: 8/5/2025 9:36:42 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 8/5/2025 9:36:42 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Data Drive Space Forecasting', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Data Drive Space Forecasting]    Script Date: 8/5/2025 9:36:42 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Data Drive Space Forecasting', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @xml NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)
DECLARE @i int = 0, @pos int, @s varchar(max), @ts varchar(max)

DECLARE @intLookback INT = -30
SELECT [DatabaseName]
      --,[FileName]
     -- ,[CurrentSizeMB]
	 ,(SELECT SUM(CurrentSizeMB) AS CurrentSizeMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(DATEADD(day, @intLookback, GETDATE()) AS DATE) GROUP BY [DatabaseName]) AS PriorMonthSizeMB
	 ,(SELECT SUM(CurrentSizeMB) AS CurrentSizeMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]) AS CurrentMonthSizeMB
     ,CASE WHEN (SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName])-(((SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(DATEADD(day, @intLookback, GETDATE()) AS DATE) GROUP BY [DatabaseName]) - (SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]))) > 0 THEN
		(SELECT SUM(CurrentSizeMB) AS CurrentSizeMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName])
	ELSE
	((SELECT SUM(CurrentSizeMB) AS CurrentSizeMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName])-(SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]))+((SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(DATEADD(day, @intLookback, GETDATE()) AS DATE) GROUP BY [DatabaseName]) - (SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]))
	END AS NextMonthSizeMB	
	  ,CASE WHEN (SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName])-(((SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(DATEADD(day, @intLookback, GETDATE()) AS DATE) GROUP BY [DatabaseName]) - (SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]))*3) > 0 THEN
		(SELECT SUM(CurrentSizeMB) AS CurrentSizeMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName])
	ELSE 
		((SELECT SUM(CurrentSizeMB) AS CurrentSizeMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName])-(SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]))+((SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(DATEADD(day, @intLookback, GETDATE()) AS DATE) GROUP BY [DatabaseName]) - (SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]))*3
	END AS ThreeMonthSizeMB	
	     ,CASE WHEN (SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName])-(((SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(DATEADD(day, @intLookback, GETDATE()) AS DATE) GROUP BY [DatabaseName]) - (SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]))*12) > 0 THEN
		(SELECT SUM(CurrentSizeMB) AS CurrentSizeMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName])
	ELSE 
		((SELECT SUM(CurrentSizeMB) AS CurrentSizeMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName])-(SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]))+((SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(DATEADD(day, @intLookback, GETDATE()) AS DATE) GROUP BY [DatabaseName]) - (SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]))*12
	END AS NextYearSizeMB	
	 --,(SELECT SUM(CurrentSizeMB) AS CurrentSizeMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]) - (SELECT SUM(CurrentSizeMB) AS CurrentSizeMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(DATEADD(day, @intLookback, GETDATE()) AS DATE) GROUP BY [DatabaseName]) AS FileGrowthMB
	 --,[FreeSpaceMB]
     --,(SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]) AS FreeSpaceMB
     --,(SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(DATEADD(day, @intLookback, GETDATE()) AS DATE) GROUP BY [DatabaseName]) AS PriorFreeSpaceMB
	 ,(SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(DATEADD(day, @intLookback, GETDATE()) AS DATE) GROUP BY [DatabaseName]) - (SELECT SUM(FreeSpaceMB) AS FreeSpaceMB FROM [FileSize] fsi WHERE [DatabaseName]=fs.DatabaseName AND [CollectionTime]=CAST(GETDATE() AS DATE) GROUP BY [DatabaseName]) AS FreeSpaceLostMB
	 ,[DriveLetter]
      --,[CollectionTime]
  INTO #tblHolder
  FROM [DBA].[dbo].[FileSize] fs
  WHERE DatabaseName NOT IN (''master'',''model'',''msdb'',''tempdb'')
  GROUP BY [DatabaseName],[DriveLetter]
  
  /*
  SELECT * FROM #tblHolder
  ORDER BY [DatabaseName]
  */

DECLARE @AvgMBGrowthPerDay DECIMAL(12,2) = 
  (SELECT (SUM(NextYearSizeMB)-SUM(CurrentMonthSizeMB))/((@intLookback*-1)*12) AS AvgMBGrowthPerDay
  FROM #tblHolder)

DECLARE @currentfreespace int = 
(SELECT DISTINCT 
CONVERT(INT,dovs.available_bytes/1048576.0) AS [Current Free Space in MB on H:]
FROM sys.master_files mf
CROSS APPLY sys.dm_os_volume_stats(mf.database_id, mf.FILE_ID) dovs
where dovs.volume_mount_point = ''H:\'')

DECLARE @numDayToFill INT = @currentfreespace/@AvgMBGrowthPerDay

/*
PRINT @AvgMBGrowthPerDay
PRINT @currentfreespace
PRINT @numDayToFill
*/
SET @xml = CAST(( SELECT cur.[DatabaseName] AS ''td'','''',cast(cast(cur.[PriorMonthSizeMB]/1024 as numeric(15,2)) as varchar(15))+'' GB'' AS ''td'','''',cast(cast(cur.[CurrentMonthSizeMB]/1024 as numeric(15,2)) as varchar(15))+'' GB'' AS ''td'','''',cast(cast(cur.[NextMonthSizeMB]/1024 as numeric(15,2)) as varchar(15))+'' GB'' AS ''td'','''', cast(cast(cur.[ThreeMonthSizeMB]/1024 as numeric(15,2)) as varchar(15))+'' GB'' AS ''td'','''',cast(cast(cur.[NextYearSizeMB]/1024  as numeric(15,2)) as varchar(15))+'' GB'' AS ''td''
FROM #tblHolder cur
ORDER BY [DatabaseName]
FOR XML PATH(''tr''), ELEMENTS ) AS NVARCHAR(MAX))

select  @s = '''', @pos = charindex(''<tr>'', @xml, 4);

while(@pos > 0)
begin
   set @i += 1;
   set @ts = substring(@xml, 1, @pos-1)
   if(@i % 2 = 1)
      set @ts = replace(@ts, ''<tr>'', ''<tr id="odd">'');
   set @s += @ts;
   set @xml = substring(@xml, @pos, len(@xml));
   set @pos =  charindex(''<tr>'', @xml, 4);
end 
set @i +=1;
set @ts = @xml;
if(@i % 2 = 1)
   set @ts = replace(@ts, ''<tr>'', ''<tr id="odd">'');
set @s += @ts;

SET @currentfreespace=@currentfreespace/1024

set @body =''<html><head><style>

   table {
      border: 6px solid rgb(18, 16, 24);     
      border-spacing: 50px 0;
      border-collapse: collapse;
      font-family:verdana,  Times, serif;
      width: 100%;
   }
   
   th {
      background-color:  rgb(65, 69, 73);
      color: white;
      margin: 10px 10px;
      padding: 10px 15px;
      border: 3px double rgb(150, 158, 166);
      box-sizing: border-box;
   }
   
   td {
      border-bottom: 1px solid black;
      padding: 10px 15px;
      color: black;
      background: rgb(189, 206, 214);
   }
  
   #odd td {
      background: rgb(238, 241, 241);
   }
  
  .wholetable {
      width: fit-content;
  }

  .header {
      border: 6px solid rgb(18, 16, 24);
      border-radius: 20px 20px 0 0;
      height:60px;
      box-sizing: border-box;
      margin: auto;
      background: rgb(43, 38, 57);
  }

  .tabletitle {
       display: inline-block;
       padding-top: 10px;
       padding-left: 15px;
       height: 100%;
  }

  .headerimg {
       display: inline-block;
       float: right;
       padding-top: 4px;
       padding-right: 10px;
  }

  img {
   margin-top:auto;
   margin-bottom: auto;
   height: 80%;
   border: 2px solid black;
  }

  h3 {
   font-size: 1.5em;
   margin: auto;
   font-family:verdana,  Times, serif;
   color: white;
 }
 .bottombox {
    border: 6px solid rgb(18, 16, 24); 
	border-radius:0 0 20px 20px;
	background: rgb(189, 206, 214);
	padding: 5px;
	width:fit-content;
	margin-top: 6px;
	display: inline-block;
 }
 .bottomresult {
      background: rgb(238, 241, 241);
	  text-align: center;
 }

</style></head><body> <div class = "wholetable" ><div class = "header"><div class ="tabletitle"><H3>ICSQLOLTP DATABASE SIZE ESTIMATES</H3></div><div class="headerimg"><img src="https://micoresolutions.com/wp-content/uploads/2020/09/MiCORE-logo-145px.png" /></div></div> <table border=1>
    <tr>
    <th> Database Name</th> <th> Prior Month File Size </th> <th> Current Month File Size </th><th> Next Month Estimated File Size </th><th>Three Month Estimated File Size</th><th>Next Year Estimated File Size</th>
   </tr>'' 
+ @s+''</table>
<div>
<div class="bottombox"><h2>Current Free Space on H:</h2><h4 class = "bottomresult">''+cast(@currentfreespace as varchar(20))+'' GB</h4></div>
<div class="bottombox"><h2>Estimated Date of Drive H Full:</h2><h4 class = "bottomresult">''+cast(DATEADD (DAY, @numDayToFill , CAST(GETDATE() AS DATE) )as varchar(20))+''</h4></div>
</div>
</body> </html>'';

EXEC msdb.dbo.sp_send_dbmail
@profile_name = ''NotifyMe'',
@body = @body,
@body_format =''HTML'',
@recipients = ''chofer@icsystem.com;brian.wineland@micoresolutions.com;domenic.betters@micoresolutions.com;blake.koonce@micoresolutions.com;scott.rogers@micoresolutions.com;'',
@subject = ''ICSQLOLTP Database Size Forecasting'';

DROP TABLE #tblHolder
', 
		@database_name=N'DBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Data Drive Space Forecasting', 
		@enabled=1, 
		@freq_type=16, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20230703, 
		@active_end_date=99991231, 
		@active_start_time=500, 
		@active_end_time=235959, 
		@schedule_uid=N'124c002a-0bec-4152-b568-c9744e48dc17'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:
GO


